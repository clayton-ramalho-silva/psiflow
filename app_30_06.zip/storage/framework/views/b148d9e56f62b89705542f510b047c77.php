<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/floatlabels.min.js')); ?>"></script>

<!-- Template Javascript -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<?php /**PATH /home1/flav6095/painelasppe.com.br/resources/views/layouts/partials/scripts.blade.php ENDPATH**/ ?>