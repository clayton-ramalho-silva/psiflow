<?php

namespace App\Http\Requests\Interview;

use Illuminate\Foundation\Http\FormRequest;

class UpdateInterviewRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'outros_idiomas' => 'required|string',
            'apresentacao_pessoal' => 'required|string',
            'saude_candidato' => 'required|string|max:255',
            'vacina_covid' => 'required|string|max:255',
            'qual_formadora' => 'required|string',
            'experiencia_profissional' => 'required|string',
            'qual_motivo_demissao' => 'required|string',
            'caracteristicas_positivas' => 'required|string',
            'habilidades' => 'required|string',
            'pontos_melhoria' => 'required|string',
            'rotina_candidato' => 'required|string',
            'disponibilidade_horario' => 'required|string',
            'familia' => 'required|string',
            'renda_familiar' => 'required|string|max:255',            
            'familia_cras' => 'required|string|max:255',
            'objetivo_longo_prazo' => 'required|string',
            'porque_ser_jovem_aprendiz' => 'required|string',
            'fonte_curriculo' => 'required|string|max:255',
            'perfil_santa_casa' => 'required|string|max:255',
            'classificacao' => 'required|string|max:255',
            'parecer_recrutador' => 'required|string', // Parecer RH
            'observacoes' => 'required|string', // Entrevistas
            'obs_rh' => 'required|string', // Observações RH
            'resume_id' => 'required|exists:resumes,id',
            'tipo_beneficio' => 'nullable|string|max:255'
            //'perfil' => 'required|string|max:255',
            //'curso_extracurricular' => 'required|string',
            //'pretencao_candidato' => 'required|string',
            //'sobre_candidato' => 'required|string',
            //'sugestao_empresa' => 'required|string',
            //'pontuacao' => 'required|string|max:255', 
        ];
    }
}
