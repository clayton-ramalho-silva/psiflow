<!doctype html>
<html lang="pt-br">
  <head>
    <?php if ($__env->exists('layouts.global.head')) echo $__env->make('layouts.global.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('css-custom'); ?>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  </head>
  <body>   

  <header>
      <!--    AQUI ENTRA O  HEADER LATERAL    -->
      <?php echo $__env->make('layouts.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('layouts.template.headerResponsive', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!--    AQUI ENTRA O  HEADER LATERAL    -->
  </header>
  
    <main>
    

      <!--    AQUI ENTRA A PAGINA    -->
      <?php echo $__env->yieldContent('content'); ?>
      <!--    AQUI ENTRA A PAGINA    -->
    </main>

    <?php echo $__env->make('layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts-custom'); ?>
  </body>
</html><?php /**PATH /home1/flav6095/painelasppe.com.br/resources/views/layouts/export.blade.php ENDPATH**/ ?>