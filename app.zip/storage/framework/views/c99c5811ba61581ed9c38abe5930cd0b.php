  <!-- Customized Bootstrap Stylesheet -->
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">

  <!-- Template Stylesheet -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/estilos.css')); ?>" type="text/css" rel="stylesheet"> <meta charset="utf-8">

  <style>
.btInt.btHistorico{
    display: none !important;
}

.sessao .bts-interna{
    justify-content: flex-start !important;
}

/* Campos desabilitados pagina create*/
.disabled-field {
    opacity: 0.6;
    pointer-events: none;
}

.disabled-field label {
    color: #6c757d;
}

.disabled-field .form-select:disabled {
    background-color: #e9ecef;
    color: #6c757d;
}

  </style><?php /**PATH /home1/flav6095/painelasppe.com.br/resources/views/layouts/partials/styles.blade.php ENDPATH**/ ?>